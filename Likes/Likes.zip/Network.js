const gainlikes = el =>{
    el.previousElementSibling.firstElementChild.innerText++
}