function likes(){
    like_count.innerText++
}