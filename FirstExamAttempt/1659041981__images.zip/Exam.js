function contact(){
    alert('Contact us at 555-5555')
}

function cartcount(){
    cart_count.innerText++
}